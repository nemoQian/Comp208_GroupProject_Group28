create view feasibleloa as
select distinct `cs_store`.`i`.`l_id` AS `l_id`, (`cs_store`.`i`.`amount` = 0) AS `cha`
from `cs_store`.`itemsondateandlocation` `i`
where `cs_store`.`i`.`l_id` in (select `cs_store`.`unfeasible`.`l_id` from `cs_store`.`unfeasible`) is false;

