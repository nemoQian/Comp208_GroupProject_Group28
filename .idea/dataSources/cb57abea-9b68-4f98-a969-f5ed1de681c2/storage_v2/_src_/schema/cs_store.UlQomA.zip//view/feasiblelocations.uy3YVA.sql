create view feasiblelocations as
select `cs_store`.`feasibleloa`.`l_id` AS `l_id`, (`cs_store`.`feasibleloa`.`cha` + 1) AS `feasible`
from `cs_store`.`feasibleloa`
union
select `cs_store`.`unfeasible`.`l_id` AS `l_id`, `cs_store`.`unfeasible`.`cha` AS `feasible`
from `cs_store`.`unfeasible`;

