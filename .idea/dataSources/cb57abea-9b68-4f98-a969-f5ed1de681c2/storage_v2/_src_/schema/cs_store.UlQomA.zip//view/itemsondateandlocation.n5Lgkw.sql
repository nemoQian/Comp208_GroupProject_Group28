create view itemsondateandlocation as
select `cs_store`.`preprocess`.`name`   AS `name`,
       `cs_store`.`preprocess`.`l_id`   AS `l_id`,
       `cs_store`.`preprocess`.`date`   AS `date`,
       `cs_store`.`preprocess`.`amount` AS `amount`
from `cs_store`.`preprocess`
where (`cs_store`.`preprocess`.`amount` <> 0)
order by `cs_store`.`preprocess`.`name`, `cs_store`.`preprocess`.`l_id`, `cs_store`.`preprocess`.`date`;

