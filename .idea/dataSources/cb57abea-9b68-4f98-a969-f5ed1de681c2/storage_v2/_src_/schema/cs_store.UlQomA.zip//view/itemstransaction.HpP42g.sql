create view itemstransaction as
select `i`.`name` AS `name`, `i`.`l_id` AS `l_id`, `i`.`date` AS `date`, `i`.`amount` AS `amount`
from `cs_store`.`itemsbroughtintoshop` `i`
union
select `cs_store`.`itemsintransactions`.`name`         AS `name`,
       `t`.`l_id`                                      AS `l_id`,
       `t`.`date`                                      AS `date`,
       (0 - `cs_store`.`itemsintransactions`.`amount`) AS `amount`
from (`cs_store`.`transactions` `t`
         join `cs_store`.`itemsintransactions` on ((`t`.`t_id` = `cs_store`.`itemsintransactions`.`t_id`)))
union
select `m`.`name` AS `name`, `m`.`from_l_id` AS `l_id`, `m`.`date` AS `date`, (0 - `m`.`amount`) AS `amount`
from `cs_store`.`movementofitems` `m`
union
select `m`.`name` AS `name`, `m`.`to_l_id` AS `l_id`, `m`.`date` AS `date`, `m`.`amount` AS `amount`
from `cs_store`.`movementofitems` `m`
order by `name`, `l_id`, `date`;

